print ("Hello World")

name = "Nizar"
print(f"Hello, {name}")
print("Hello, " + name)

num = str(3)
print(f"Hello, {num}!")
print("Hello, " + num + "!")

foodone = "pizza"
foodtwo = "pasta"

print("i like to eat {} and {}".format(foodone,foodtwo))
print(f"i like to eat {foodone} and {foodtwo}")
