import parent

print(locals())