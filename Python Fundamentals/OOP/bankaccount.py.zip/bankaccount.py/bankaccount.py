class BankAccount:
    instances = []
    account_balance = 0
    
    def __init__(self, int_rate, balance):
        self.int_rate = int_rate
        self.account_balance = balance
        BankAccount.instances.append(self)

    def deposit(self, amount):
        self.account_balance += amount
        return(self)

    def withdraw(self, amount):
        if self.account_balance >= amount:
            self.account_balance -= amount
        else:
            print('Insufficient funds: Charging a $5 fee')
            self.account_balance - 5
        return(self)

    def display_account_info(self):
        print(f'Balance: ${self.account_balance}')
        return(self)

    def yield_interest(self):
        if self.account_balance > 0:
            self.account_balance += self.account_balance * self.int_rate
            percentage = self.int_rate
            print('With interest rate of: {:.0%}'.format(percentage))
        return(self)
    
    def __str__(self):
        return f"Interest rate: {self.int_rate}, Balance: {self.account_balance}"
    
    @classmethod
    def show_instances(cls):
        for id, instance in enumerate(cls.instances, start=1):
            print(f"Class Instance {id}: {instance}")

BankAccount1 = BankAccount(0.01, 1200)
BankAccount2 = BankAccount(0.03, 400)

BankAccount1.deposit(120).deposit(300).deposit(100).withdraw(200).yield_interest().display_account_info()
print()
BankAccount2.deposit(200).deposit(100).withdraw(150).withdraw(400).withdraw(150).withdraw(100).yield_interest().display_account_info()
print()
BankAccount.show_instances()
