num1 = 42 #Numbers/integer
num2 = 2.3 #Numbers/float
boolean = True #Boolean
string = 'Hello World' #Strings
pizza_toppings = ['Pepperoni', 'Sausage', 'Jalepenos', 'Cheese', 'Olives'] #List
person = {'name': 'John', 'location': 'Salt Lake', 'age': 37, 'is_balding': False} #Dictionary
fruit = ('blueberry', 'strawberry', 'banana') #Tuples
print(type(fruit)) #type check
print(pizza_toppings[1]) #access value
pizza_toppings.append('Mushrooms') #add value
print(person['name']) #access value
person['name'] = 'George' #change value
person['eye_color'] = 'blue' #initialize
print(fruit[2]) #access value

if num1 > 45: #apply if condition met
    print("It's greater") #num1 = 42
else: #if condition not met print this
    print("It's lower") #this will be printed

if len(string) < 5: #apply if condition met
    print("It's a short word!") #string = 5
elif len(string) > 15: #apply else if condition met
    print("It's a long word!") #string is less than 15
else: #if all conditions not met apply this
    print("Just right!") #this will be printed

for x in range(5): #set x times
    print(x) #print x 5 times
for x in range(2,5): #
    print(x) #print x 2 times
for x in range(2,10,3): #x in up to 2, x up to 10, x up to 3
    print(x) #print x 2 times, then 10 times, then 3 times
x = 0 #variable declaration
while(x < 5): #as long as x is less than 5 keep printing x
    print(x) #printing x
    x += 1 #infinite loop
    
    

pizza_toppings.pop() #delete last value
pizza_toppings.pop(1) #delete specific(indexed) value

print(person) #{'name': 'John', 'location': 'Salt Lake', 'age': 37, 'is_balding': False, 'eye_color': 'blue'}
person.pop('eye_color') #delete value
print(person) #{'name': 'John', 'location': 'Salt Lake', 'age': 37, 'is_balding': False}

for topping in pizza_toppings: #access value
    if topping == 'Pepperoni': #initialize
        continue #apply the code under this condition
    print('After 1st if statement') #
    if topping == 'Olives': #initialize
        break #pause the code under this condition

def print_hello_ten_times(): #defining a function
    for num in range(10): #set a number from 0 up to 10
        print('Hello') #prints hello 10 times

print_hello_ten_times() #calling the function/prints hello 10 times

def print_hello_x_times(x): #defining a function with parameter
    for num in range(x): #set a number with a unknown range
        print('Hello') #print hello x times

print_hello_x_times(4) #print hello 4 times

def print_hello_x_or_ten_times(x = 10): #defining a function(variable declaration)
    for num in range(x): #set a number from 0 up to 10
        print('Hello') #print hello 10 times

print_hello_x_or_ten_times() #print hello 10 times
print_hello_x_or_ten_times(4) #print hello 4 times

#comment
#multiline

"""
Bonus section
"""

#comment
#single line

print(num3) #NameError: name <num3> is not defined
num3 = 72 #variable declaration
fruit[0] = 'cranberry' #TypeError: 'tuple' object does not support item assignment
print(person['favorite_team']) #KeyError: 'favorite_team'
print(pizza_toppings[7]) #IndexError: list index out of range
print(boolean) #True
fruit.append('raspberry') #AttributeError: 'tuple' object has no attribute 'append'
fruit.pop(1) #AttributeError: 'tuple' object has no attribute 'pop'