def greater_than_sec(array0):
    if len(array0) < 2:
        return False

    array1 = []
    num = array0[1]
    for element in array0:
        if element > num:
            array1.append(element)

    print(len(array1))
    return array1

print(greater_than_sec([5,3,8,2,9,12,1]))
print(greater_than_sec([6]))
