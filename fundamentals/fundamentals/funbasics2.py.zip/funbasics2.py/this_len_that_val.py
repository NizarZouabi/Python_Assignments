def len_and_val(size,value):
    new_list = [value] * size
    return new_list

print(len_and_val(4,7))
print(len_and_val(6,2))
