def print_and_return(nums):
    print(nums[0])
    return nums[1]

print(print_and_return([4, 6]))
