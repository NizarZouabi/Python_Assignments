def countdown(num):
    number = []
    for num in range(num, -1, -1):
        number.append(num)
    return number

print(countdown(8))
