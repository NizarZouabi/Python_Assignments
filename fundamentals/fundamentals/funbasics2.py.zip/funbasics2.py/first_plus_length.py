def first_plus_length(list):
    if len(list) > 0:
        return(len(list) + list[0])
    else:
        return 0

print(first_plus_length([3,5,6,7,9]))
