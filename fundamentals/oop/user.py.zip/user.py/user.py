class User:
    
    def __init__(self, name, balance):
        self.user_name = name
        self.user_balance = balance

    def make_withdrawal(self, amount):
        if amount <= self.user_balance:
            self.user_balance -= amount
        else:
            print("The given Numbers exceeds your Balance")
    
    def make_deposit(self, amount):
        self.user_balance += amount

    def display_user_balance(self,):
        print(f"User: {self.user_name}, Balance: {self.user_balance}")

    def transfer_money(self, other_user, amount):
        if amount <= self.user_balance:
            self.user_balance -= amount
            other_user.user_balance += amount
            print(f'{amount} Transferred')
        else:
            print("Insufficient balance")
