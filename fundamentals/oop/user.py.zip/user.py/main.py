from user import User

user1 = User("Nizar", 1520)
user2 = User("Other_user", 600)
user3 = User("Amal", 850)

user1.make_deposit(20)
user1.display_user_balance()
user1.make_deposit(60)
user1.display_user_balance()
user1.make_deposit(80)
user1.display_user_balance()
user1.make_withdrawal(50)
print(f'User: {user1.user_name} withdrawed money')
user1.display_user_balance()

print()

user2.make_deposit(300)
user2.display_user_balance()
user2.make_deposit(230)
user2.display_user_balance()
user2.make_withdrawal(400)
print(f'User: {user2.user_name} withdrawed money')
user2.display_user_balance()
user2.make_withdrawal(80)
print(f'User: {user2.user_name} withdrawed money')
user2.display_user_balance()

print()

user3.make_deposit(700)
user3.display_user_balance()
user3.make_withdrawal(400)
print(f'User: {user3.user_name} withdrawed money')
user3.display_user_balance()
user3.make_withdrawal(25)
print(f'User: {user3.user_name} withdrawed money')
user3.display_user_balance()
user3.make_withdrawal(50)
print(f'User: {user3.user_name} withdrawed money')
user3.display_user_balance()

print()

user1.transfer_money(user2, 170)
print(f'{user1.user_name} Transferred money to {user2.user_name}')
user1.display_user_balance()
user2.display_user_balance()
