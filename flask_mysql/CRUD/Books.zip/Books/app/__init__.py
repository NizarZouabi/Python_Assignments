from flask import Flask
app = Flask(__name__)
app.secret_key = "fe5r4ge32d4tr1gh3f"
