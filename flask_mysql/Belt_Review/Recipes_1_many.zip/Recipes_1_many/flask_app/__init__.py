from flask import Flask
app = Flask(__name__)
app.secret_key = "kjf54ze3s2rdf465f"